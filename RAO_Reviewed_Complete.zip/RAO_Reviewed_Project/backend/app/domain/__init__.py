"""Canonical domain layer."""
